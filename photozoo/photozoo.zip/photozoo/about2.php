<?php include('includes/overallheader.php'); ?>
<h1>About us</h1>
<p>Welcome to PhotoZoo. Our website is designed to well organize your digital photos. 
	PhotoZoo is a self-photo management website which enables the you to customize your albums and store digital photos in chosen albums orderly. 
	It can reduce your dependency of memory stick and can even add the description of each album. 
	</p>
	<p>Please contact us if you have any question.</p>
	<p>Authorship: Yilin Hao</p>
	<p>Email: yh5e11@soton.ac.uk</p>

<?php include('includes/overallfooter.php'); ?>	