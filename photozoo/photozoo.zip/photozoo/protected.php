<?php include('includes/overallheader.php'); ?> 	
<h1>Sorry,you need to be logged in to do that!</h1>
<p>Please register or log in.</p>
<?php include 'includes/overallfooter.php';?>	