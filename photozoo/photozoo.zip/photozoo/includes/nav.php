	<div class="navfixtop">
    <div class="navbar navbar-inverse">
    <div class="navbar navbar-fixed-top">
    <div class="navbar">
	 <div class="navbar-inner">
     
      <div class="container">
      <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse" >       
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        </a>
     
			<a class="brand" href="#">PhotoZoo</a>
            <ul class="nav">
            
            <li class="active"><a href="">Home</a></li>
                <li><a href="register.php">Register</a></li>
                <li><a href="index.php">Login</a></li>
                <li><a href="about1.php">About</a></li>                                            
            </ul>
    </div>                   				
    </div>
    </div>
    </div>
</div>    
 <!-- http://twitter.github.com/bootstrap/components.html#navs-->