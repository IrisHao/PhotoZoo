<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    	<title></title>
        
        
        <link rel="stylesheet" href="style/css.css" type="text/css"/>
        <link href="style/css/bootstrap.min.css" rel="stylesheet" media="screen"  />
        <script src="style/js/bootstrap.min.js"></script>
		<script src="http://code.jquery.com/jquery-latest.js"></script>

        <script type="text/javascript">
			$(function(){
			   $('.carousel').carousel();
			});						
		</script>      
        
    </head>
    
    <body>
    <?php include('includes/nav.php'); ?>
                           
			<div id="content">
                <h1><a class="text-info" href="#" style="padding: 100px; font-size: xx-large; color: #F66;"><i class="icon-star"></i> <strong>PhotoZoo</strong></a></h1>
                
                 <div id="myCarousel" class="carousel slide">
                 <!-- Carousel items-->
                      <div class="carousel-inner">
                            <div class="active item"><img src="img/images5.jpg" alt="img2" width="800" height="228" style="text-align:center"></div>
                            <div class="item"><img src="img/images5.jpg" alt="img5" width="800" height="228" style="text-align:center"></div>
                            <div class="item"> <img src="img/images1.jpg" width="800" height="228" style="text-align:center"></div>
                      </div>
           <!-- Carousel nav--> 
               <a class="carousel-control left" href="#myCarousel"  data-slide="prev">&lsaquo;</a>
               <a class="carousel-control right" href="#myCarousel" data-slide="next">&rsaquo;</a>
           </div>
             
             
		<div class="introduction">
		<p>Welcome to PhotoZoo. Our website is designed to well organize your digital photos.</p>
		<p><a href="register.php">Join</a> us today!!</p>
        </div>