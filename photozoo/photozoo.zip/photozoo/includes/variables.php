<?php

$heading='WebDesigner PHP';

$footer='Copyright &copy; 2013 INFO2002';

?>